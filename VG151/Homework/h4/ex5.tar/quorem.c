#include<stdio.h>
#include<stdlib.h>
int quo(int a,int b){ return a/b; }
int rem(int a,int b){ return a%b; }

