#ifndef _QUOREM_H_
	#define _QUOREM_H_

	int quo(int a,int b);
	int rem(int a,int b);

#endif
