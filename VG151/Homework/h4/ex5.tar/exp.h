#ifndef _EXP_H_
	#define _EXP_H_

	long int mpow(int a,int b);

#endif
