#ifndef _SUM_H_
	#define _SUM_H_
	
	int sum(int a,int b);

#endif
