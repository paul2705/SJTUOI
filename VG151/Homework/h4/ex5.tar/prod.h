#ifndef _PROD_H_
	#define _PROD_H_

	int prod(int a,int b);

#endif
