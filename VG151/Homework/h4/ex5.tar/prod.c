#include<stdio.h>
#include<stdlib.h>
int prod(int a,int b){ return a*b; }

