#include<stdio.h>
#include<stdlib.h>
#include<math.h>
long int mpow(int a,int b){ return pow(a,b); }

